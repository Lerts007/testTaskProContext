<script setup>
import LeftPanel from "./components/LeftPanel.vue";
import RightPanel from "./components/RightPanel.vue";
const lists = [
  {
    name: "List 1",
    collapsed: false,
    selected: false,
    items: [
      { name: "Item 1", quantity: 5, color: "#ff0000", selected: false },
      { name: "Item 2", quantity: 3, color: "#00ff00", selected: false },
    ],
  },
  {
    name: "List 2",
    collapsed: false,
    selected: false,
    items: [
      { name: "Item 1", quantity: 5, color: "#ffas00", selected: false },
      { name: "Item 2", quantity: 3, color: "#00ff03", selected: false },
    ],
  },
];
</script>

<template>
  <main>
    <LeftPanel :lists="lists" />
    <!-- <RightPanel :lists="lists" /> -->
  </main>
</template>

<style scoped>
main {
  max-width: 1200px;
  min-height: 300px;

  padding: 20px;

  display: flex;
  gap: 40px;

  border: 1px solid #ccc;
}
</style>
