<template>
  <div class="rightPanel">
    <div v-for="(list, index) in lists" :key="index">
      <div class="list">
        <h3>{{ list.name }}</h3>
        <button @click="sortList(list)">Sort</button>
        <button @click="shuffleList(list)">Shuffle</button>
      </div>
      <div>
        <div v-for="(item, i) in list.items" :key="i" v-if="item.selected">
          <div class="item-block" :style="{ backgroundColor: item.color }">
            <span>{{ item.quantity }}</span>
            <span @click="removeItem(item)">X</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
const props = defineProps(["lists"]);

const sortList = (list) => {
  list.items.sort((a, b) => a.quantity - b.quantity);
};
const shuffleList = (list) => {
  for (let i = list.items.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [list.items[i], list.items[j]] = [list.items[j], list.items[i]];
  }
};
const removeItem = (item) => {
  item.selected = false;
};
</script>

<style lang="scss" scoped>
.rightPanel {
  border: 1px solid #ccc;
}
.list {
  margin-bottom: 20px;
}
.item-block {
  display: inline-block;
  margin-right: 10px;
  padding: 5px;
  cursor: pointer;
}
</style>
