<template>
  <div>
    <button :class="{ active: isActive }" @click="toggleList(list)">V</button>
    <input
      type="checkbox"
      v-model="list.selected"
      @change="selectAllItems(list)"
    />
    <label>{{ list.name }}</label>
  </div>
  <div class="items" v-if="!list.collapsed">
    <Item
      v-for="(item, i) in list.items"
      :key="i"
      :item="item"
      @item-selected="itemSelected"
    />
  </div>
</template>

<script setup>
import { ref } from "vue";

import Item from "./Item.vue";

const props = defineProps(["list"]);
const isActive = ref(false);

const selectAllItems = (list) => {
  const allSelected = list.items.every((item) => item.selected);
  list.items.forEach((item) => (item.selected = !allSelected));
};

const toggleList = (list) => {
  list.collapsed = !list.collapsed;
  isActive.value = !isActive.value;
};

const itemSelected = (item, selected) => {
  item.selected = selected;
  const allSelected = item.list.items.every((item) => item.selected);
  item.list.selected = allSelected;
};
</script>

<style lang="scss" scoped>
.items {
  padding-left: 50px;
}
button {
  border: none;
  background-color: transparent;
  font-size: 1.5rem;
  cursor: pointer;
}
.active {
  transform: rotate(-90deg);
}
</style>
