<template>
  <div class="item">
    <input
      type="checkbox"
      :id="item.name"
      class="checkbox"
      v-model="selected"
      @change="selectItem"
    />
    <label :for="item.name">{{ item.name }}</label>

    <label>
      {{ item.quantity }}
      <input class="item-color" type="color" v-model="item.color" />
    </label>
  </div>
</template>

<script setup>
const props = defineProps(["item"]);
console.log(props.item);
let selected = false;
const selectItem = () => {
  this.$emit("item-selected", this.item, this.selected);
};
</script>

<style scoped>
.item {
  margin-bottom: 5px;

  display: flex;
  justify-content: space-between;
}
label {
  display: flex;
  align-items: center;
}
.checkbox {
  position: absolute;
  z-index: -1;
  opacity: 0;
  & + label {
    display: inline-flex;
    align-items: center;
    user-select: none;
  }
  & + label::before {
    content: "";
    display: inline-block;
    width: 1em;
    height: 1em;
    flex-shrink: 0;
    flex-grow: 0;
    border: 1px solid #adb5bd;
    border-radius: 0.25em;
    margin-right: 0.5em;
    background-repeat: no-repeat;
    background-position: center center;
    background-size: 50% 50%;
  }
  &:checked + label::before {
    content: "✓";

    border-color: #0b76ef;
    background-color: #0b76ef;
    color: white;
  }
}
.item-color {
  -webkit-appearance: none;
  -moz-appearance: none;
  appearance: none;

  width: 30px;
  height: 30px;

  margin-left: 5px;
  padding: 0;

  background-color: transparent;
  border: none;
  cursor: pointer;

  &::-webkit-color-swatch {
    border-radius: 50%;
    border: none;
  }
  &::-moz-color-swatch {
    border-radius: 50%;
    border: none;
  }
}
</style>
