<template>
  <div class="leftPanel">
    <div class="list" v-for="(list, index) in lists" :key="index">
      <List :list="list" />
    </div>
  </div>
</template>
<script setup>
import List from "./List.vue";

const props = defineProps(["lists"]);
</script>

<style lang="scss" scoped>
.leftPanel {
  border: 1px solid #ccc;
}
.list {
  width: 300px;
  margin-bottom: 30px;
}
</style>
